<?php
/**
 * @package JoomlaPack
 * @subpackage Installer
 * @copyright Copyright (C) 2009 JoomlaPack Developers. All rights reserved.
 * @author Nicholas K. Dionysopoulos - http://www.dionysopoulos.me
 * @version 4.0
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL v3 or later
 *
 * JoomlaPack Installer 4 Logic: Site setup
 */

defined('_JPI') or die('Direct access is not allowed');

// Make sure we are in RAW mode
$output =& JPOutput::getInstance();
$output->setMode('raw');

// Set HTTP headers
header("Expires: Mon, 1 Dec 2003 01:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("MIME-Version: 1.0");
header("Content-Type: text/xml");

$act = getParam('act');

switch($act)
{
	case 'findFtpRoot':
		// Fetch data from the request parameters
		$ftp_host = getParam('ftp_host');
		$ftp_port = getParam('ftp_port');
		$ftp_user = getParam('ftp_user');
		$ftp_pass = getParam('ftp_pass');
		// Try to connect to the FTP
		require_once(JPATH_INSTALLATION.DS.'includes'.DS.'ftp.php');
		$ftp =& JPFTP::getInstance($ftp_host, $ftp_port, $ftp_user, $ftp_pass, null);
		if(!$ftp->connect(true))
		{
			// Could not connect to FTP
			$ret = array('error' => JPText::_('ERROR_CANTCONNECTFTP'));
			break;
		}
		$root = $ftp->findRoot();
		if($root === false)
		{
			$ret = array('error' => JPText::_('ERROR_CANTFINDROOT'));
		} 
		else
		{
			// Make the return array
			$ret = array('root' => $root);
			// Save our successful settings to the configuration object
			require_once(JPATH_INSTALLATION.DS.'includes'.DS.'configuration.php');
			$configuration =& JPConfiguration::getInstance();
			$configuration->set('ftp_host',$ftp_host);
			$configuration->set('ftp_port',$ftp_port);
			$configuration->set('ftp_user',$ftp_user);
			$configuration->set('ftp_pass',$ftp_pass);
		}
		break;

	case 'checkFtp':
		// Fetch data from the request parameters
		$ftp_host = getParam('ftp_host');
		$ftp_port = getParam('ftp_port');
		$ftp_user = getParam('ftp_user');
		$ftp_pass = getParam('ftp_pass');
		$ftp_root = getParam('ftp_root');
		// Try to connect to the FTP
		require_once(JPATH_INSTALLATION.DS.'includes'.DS.'ftp.php');
		$ftp =& JPFTP::getInstance($ftp_host, $ftp_port, $ftp_user, $ftp_pass, $ftp_root);
		if(!$ftp->connect(true))
		{
			// Could not connect to FTP
			$ret = array('error' => JPText::_('ERROR_CANTCONNECTFTP'));
			break;
		}
		else
		{
			// Make the return array
			$ret = array('error' => ''); // Blank error means OK!
			// Save our successful settings to the configuration object
			require_once(JPATH_INSTALLATION.DS.'includes'.DS.'configuration.php');
			$configuration =& JPConfiguration::getInstance();
			$configuration->set('ftp_host',$ftp_host);
			$configuration->set('ftp_port',$ftp_port);
			$configuration->set('ftp_user',$ftp_user);
			$configuration->set('ftp_pass',$ftp_pass);
			$configuration->set('ftp_root',$ftp_root);
		}
		break;
		
	default:
		$ret = array('error' => JPText::_('ERROR_INVALIDCOMMAND'));
}

echo renderXML($ret);