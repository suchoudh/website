<?php
/**
 * @package JoomlaPack
 * @subpackage Installer
 * @copyright Copyright (C) 2009 JoomlaPack Developers. All rights reserved.
 * @author Nicholas K. Dionysopoulos - http://www.dionysopoulos.me
 * @version 4.0
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL v3 or later
 *
 * JoomlaPack Installer 4 main page
 */

// Flag this as a parent file
define('_JPI', '4.0');

// Minimum script execution time: 2 seconds
define('MINEXECTIME', 2000);

// Remove error reporting
@error_reporting(E_NONE);

// Setup some useful constants
define('DS', DIRECTORY_SEPARATOR);
define('JPATH_SITE', realpath(dirname(__FILE__).DS.'..') );
define('JPATH_INSTALLATION', realpath(dirname(__FILE__)) );

// Output buffering begins before we start doing anything at all
@ob_start();

// Load base files
require_once(JPATH_INSTALLATION.DS.'includes'.DS.'utils.php'); // Utilities
require_once(JPATH_INSTALLATION.DS.'includes'.DS.'translate.php'); // Translation
require_once(JPATH_INSTALLATION.DS.'includes'.DS.'storage.php'); // Temporary Storage
require_once(JPATH_INSTALLATION.DS.'includes'.DS.'output.php'); // Output class
require_once(JPATH_INSTALLATION.DS.'includes'.DS.'automation.php'); // Automation class
require_once(JPATH_INSTALLATION.DS.'includes'.DS.'antidos.php'); // Protection from anti-DoS solutions (no more 403's!)

// Initialize the global $view array
global $view;
unset($view); // Destroy any variable trickily passed to this script...
$view = array(); // Initialize to an empty array

// Enforce minimum script execution time (start-up)
enforce_minexectime(true);

// Run the logic depending on the task
$task = getParam('task','index');
switch($task)
{
	case "index": // Requirements check
		require_once(JPATH_INSTALLATION.DS.'includes'.DS.'logic'.DS.'index.php'); // Run the logic
		require_once(JPATH_INSTALLATION.DS.'includes'.DS.'output'.DS.'index.php'); // Run the view
		break;

	case "dbnext": // Iterate to the next database
	case "dbprev": // Iterate to the previous database
		require_once(JPATH_INSTALLATION.DS.'includes'.DS.'logic'.DS.'dbsetup.php'); // Run the logic
		require_once(JPATH_INSTALLATION.DS.'includes'.DS.'output'.DS.'dbsetup.php'); // Run the view
		break;

	case "restore": // Restores the current database (called by AJAX)
		require_once(JPATH_INSTALLATION.DS.'includes'.DS.'logic'.DS.'restore.php'); // Run the logic
		// There is no "view" for this page. The logic produces the AJAX output.
		break;

	case "setup": // Site setup
		require_once(JPATH_INSTALLATION.DS.'includes'.DS.'logic'.DS.'setup.php'); // Run the logic
		require_once(JPATH_INSTALLATION.DS.'includes'.DS.'output'.DS.'setup.php'); // Run the view
		break;

	case "ajax": // AJAX power for site setup, e.g. FTP check
		require_once(JPATH_INSTALLATION.DS.'includes'.DS.'logic'.DS.'ajax.php'); // Run the logic
		// There is no "view" for this page. The logic produces the AJAX output.
		break;

	case "finish": // We just finished!
		require_once(JPATH_INSTALLATION.DS.'includes'.DS.'logic'.DS.'finish.php'); // Run the logic
		require_once(JPATH_INSTALLATION.DS.'includes'.DS.'output'.DS.'finish.php'); // Run the view
		break;

	default:
		// This is something not allowed. Die.
		die('Invalid task');
		break;
}

// Get the page's output
$content = ob_get_clean();

// Send the page data
$output =& JPOutput::getInstance();
$output->setContent($content);
$output->output();

// Finally, save the Storage
$storage =& JPStorage::getInstance();
$storage->saveData();

// Enforce minimum script execution time (finalization)
enforce_minexectime(false);