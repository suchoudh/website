<?php
header( 'Location: http://www.artnartist.in' ) ;
?>
