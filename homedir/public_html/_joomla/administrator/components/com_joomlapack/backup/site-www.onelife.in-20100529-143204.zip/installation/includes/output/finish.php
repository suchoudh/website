<?php
/**
 * @package JoomlaPack
 * @subpackage Installer
 * @copyright Copyright (C) 2009 JoomlaPack Developers. All rights reserved.
 * @author Nicholas K. Dionysopoulos - http://www.dionysopoulos.me
 * @version 4.0
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL v3 or later
 *
 * JoomlaPack Installer 4 Output: Finish up
 */

defined('_JPI') or die('Direct access is not allowed');

global $view;
extract($view);

if($confwritten):?>
<h2><?php echo JPText::_('CONF_WRITTEN')?></h2>
<?php else: ?>
<h2><?php echo JPText::_('CONF_NOTWRITTEN')?></h2>
<p><?php echo JPText::_('CONF_NOTWRITTEN_PARA')?></p>
<div id="dialog" title="<?php echo JPText::_('DLG_NOTWRITTEN_TITLE')?>">
	<p><?php echo JPText::_('DLG_NOTWRITTEN_BODY1') ?></p>
	<p><?php echo JPText::_('DLG_NOTWRITTEN_BODY2') ?></p>
</div>
<pre class="scrollable"><?php echo htmlentities($confdata); ?></pre>
<script type="text/javascript" language="javascript">
	$(function() {
			$("#dialog").dialog({
				autoOpen: true,
				closeOnEscape: true,
				height: 200,
				width: 400,
				hide: 'slide',
				modal: true,
				position: 'center',
				show: 'slide'
			});
	});
</script>
<?php endif; ?>

<p><?php echo JPText::_('MESSAGE_FINISH1')?></p>
<p><?php echo JPText::_('MESSAGE_FINISH2')?></p>