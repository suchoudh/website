<?php
/**
 * @package JoomlaPack
 * @subpackage Installer
 * @copyright Copyright (C) 2009 JoomlaPack Developers. All rights reserved.
 * @author Nicholas K. Dionysopoulos - http://www.dionysopoulos.me
 * @version 4.0
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL v3 or later
 *
 * JoomlaPack Installer 4 Logic: The first page to load
 */

defined('_JPI') or die('Direct access is not allowed');

global $view; // Import global $view variable

require_once(JPATH_INSTALLATION.DS.'includes'.DS.'configuration.php'); // Configuration class

// Begin by grabbing and caching the configuration (creating an instance automatically does that!)
$configuration =& JPConfiguration::getInstance();

// Check requirements
$phpOptions = array();
$phpRecommended = array();

$phpOptions[] = array (
	'label' => JPText::_('PHP_VERSION').' >= 4.3.10',
	'state' => !(phpversion() < '4.3.10')
);
$phpOptions[] = array (
	'label' => '- '.JPText::_('ZLIB_SUPPORT'),
	'state' => extension_loaded('zlib')
);
$phpOptions[] = array (
	'label' => '- '.JPText::_('XML_SUPPORT'),
	'state' => extension_loaded('xml')
);
$phpOptions[] = array (
	'label' => '- '.JPText::_('MYSQL_SUPPORT'),
	'state' => (function_exists('mysql_connect') || function_exists('mysqli_connect'))
);
if (extension_loaded( 'mbstring' )) {
	$mbDefLang = strtolower( ini_get( 'mbstring.language' ) ) == 'neutral';
	$mbOvl = ini_get('mbstring.func_overload') != 0;
	$phpOptions[] = array (
		'label' => JPText::_( 'MB_DEFAULT_LANGUAGE' ),
		'state' => $mbDefLang
	);
	$phpOptions[] = array (
		'label' => JPText::_('MB_OVERLOAD'),
		'state' => !$mbOvl
	);
}
$cW = (@ file_exists('../configuration.php') && @is_writable('../configuration.php')) || @is_writable('../');
$phpOptions[] = array (
	'label' => 'configuration.php '.JPText::_('WRITABLE'),
	'state' => $cW ? 'Yes' : 'No',
	'notice' => $cW ? '' : JPText::_('NOTICEYOUCANSTILLRESTORE'),
	'optional' => true
);
$lists['phpOptions'] = & $phpOptions;

// Process requirements
$requirementsMet = true;
foreach($phpOptions as $option)
{
	if(!isset($option['optional']))
	{
		$requirementsMet = $requirementsMet && $option['state'];
	}
}
$lists['requirementsMet'] = $requirementsMet;

// Check recommendations
$phpRecommended = array (
array (
JPText::_('SAFE_MODE'),
	'safe_mode',
	false
	),
	array (
	JPText::_('DISPLAY_ERRORS'),
	'display_errors',
	false
	),
	array (
	JPText::_('FILE_UPLOADS'),
	'file_uploads',
	true
	),
	array (
	JPText::_('MAGIC_QUOTES_RUNTIME'),
	'magic_quotes_runtime',
	false	
	),
	array (
	JPText::_('REGISTER_GLOBALS'),
	'register_globals',
	false
	),
	array (
	JPText::_('OUTPUT_BUFFERING'),
	'output_buffering',
	false
	),
	array (
	JPText::_('SESSION_AUTO_START'),
	'session.auto_start',
	false
	)
);

foreach ($phpRecommended as $setting)
{
	$lists['phpSettings'][] = array (
		'label' => $setting[0],
		'setting' => $setting[2],
		'actual' => ini_get($setting[1]) == '1',
		'state' => (ini_get($setting[1]) == 1) == $setting[2]
	);
}

// Check writable directories - Temporary
$tmpDir = $configuration->get('tmp_path', JPATH_SITE.DS.'tmp');
if(!@is_dir($tmpDir)) $tmpDir = JPATH_SITE.DS.'tmp';
$directories[] = array(
	'label'		=> JPText::_('TMP_DIR'),
	'directory'	=> $tmpDir,
	'writable'	=> @is_writable($tmpDir)
);

// Check writable directories - Log
$logDir = $configuration->get('log_path', JPATH_SITE.DS.'logs');
if(!@is_dir($logDir)) $logDir = JPATH_SITE.DS.'logs';
$directories[] = array(
	'label'		=> JPText::_('LOG_DIR'),
	'directory'	=> $logDir,
	'writable'	=> @is_writable($logDir)
);

// Check writable directories - Cache
$cacheDir = JPATH_SITE.DS.'cache';
$directories[] = array(
	'label'		=> JPText::_('CACHE_DIR'),
	'directory'	=> $cacheDir,
	'writable'	=> @is_writable($cacheDir)
);

$lists['directories'] = $directories;

// Pass the results to the global $view array
$storage =& JPStorage::getInstance();
$output =& JPOutput::getInstance();
$view = $lists;

// Is the storage working? If not, requirements are not met and we show an error
// message.
$view['isStorageWorking'] = $storage->isStorageWorking();
if(!$view['isStorageWorking']) {
	$requirementsMet = false;
	$output->setError(JPText::_('ERROR_STORAGE_NOT_WORKING'));
}

// Pass on the automation information
$automation =& JPAutomation::getInstance();

// Set some output parameters - The previous/next buttons
if($requirementsMet)
{
	$output->setButtons(null,"submitForm('dbnext')");
	if($automation->hasAutomation())
	{
		$output->setAutomation('submitForm("dbnext");');
	}
}
else
{
	$output->setButtons(null,"submitForm('index')");
}

// Clear the storage and set last shown step to 'index' (this page)
$storage->reset();
$storage->set('step','index');