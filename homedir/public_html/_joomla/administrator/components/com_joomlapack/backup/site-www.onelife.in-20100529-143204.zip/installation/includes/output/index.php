<?php
/**
 * @package JoomlaPack
 * @subpackage Installer
 * @copyright Copyright (C) 2009 JoomlaPack Developers. All rights reserved.
 * @author Nicholas K. Dionysopoulos - http://www.dionysopoulos.me
 * @version 4.0
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL v3 or later
 *
 * JoomlaPack Installer 4 Output: The first page to load
 */

defined('_JPI') or die('Direct access is not allowed');

global $view;
extract($view);

?>
<h2><?php echo JPText::_('TITLE_SERVERSETUP') ?></h2>

<div id="accordion">

<h3><?php echo JPText::_('REQUIREMENTS') ?></h3>
<div class="categoryitems">
<table>
	<thead>
		<tr>
			<th><?php echo JPText::_('ITEM'); ?></th>
			<th><?php echo JPText::_('REALSET'); ?></th>
		</tr>
	</thead>
	<tbody>
	<?php foreach($phpOptions as $option): ?>
		<tr>
			<td><?php echo $option['label'] ?></td>
			<td><?php echo $option['state'] ? '<span class="green">'.JPText::_('Yes').'</span>' : '<span class="red">'.JPText::_('No').'</span>'  ?>
				<?php if(isset($option['notice'])): ?>
				<br/><?php echo $option['notice'] ?>
				<?php endif; ?>
			</td>
		</tr>
	<?php endforeach; ?>
	</tbody>
</table>
</div>

<h3><?php echo JPText::_('OPTIONAL_SETTINGS') ?></h3>
<div class="categoryitems">
<table>
	<thead>
		<tr>
			<th><?php echo JPText::_('ITEM'); ?></th>
			<th><?php echo JPText::_('RECSET'); ?></th>
			<th><?php echo JPText::_('REALSET'); ?></th>
		</tr>
	</thead>
	<tbody>
	<?php foreach($phpSettings as $option): ?>
		<tr>
			<td><?php echo $option['label'] ?></td>
			<td><?php echo $option['setting'] ? JPText::_('Yes') : JPText::_('No') ?></td>
			<td><?php echo $option['state'] ? '<span class="green">' : '<span class="red">';
				echo $option['actual'] ? JPText::_('Yes') : JPText::_('No'); ?></span>
				<?php if(isset($option['notice'])): ?>
				<br/><?php echo $option['notice'] ?>
				<?php endif; ?>
			</td>
		</tr>
	<?php endforeach; ?>
	</tbody>
</table>
</div>

<h3><?php echo JPText::_('DIRECTORIES') ?></h3>
<div class="categoryitems">
<table>
	<thead>
		<tr>
			<th><?php echo JPText::_('ITEM'); ?></th>
			<th><?php echo JPText::_('REALSET'); ?></th>
		</tr>
	</thead>
	<tbody>
	<?php foreach($directories as $option): ?>
		<tr>
			<td><?php echo $option['label'] ?><br/><tt><?php echo $option['directory'] ?></tt></td>
			<td><?php echo $option['writable'] ? '<span class="green">' : '<span class="red">';
				echo $option['writable'] ? JPText::_('Yes') : JPText::_('No'); ?></span>
			</td>
		</tr>
	<?php endforeach; ?>
	</tbody>
</table>
</div>

</div>