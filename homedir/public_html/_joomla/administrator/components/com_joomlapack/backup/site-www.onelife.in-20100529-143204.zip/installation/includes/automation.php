<?php
/**
 * @package JoomlaPack
 * @subpackage Installer
 * @copyright Copyright (C) 2009 JoomlaPack Developers. All rights reserved.
 * @author Nicholas K. Dionysopoulos - http://www.dionysopoulos.me
 * @version 4.0
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL v3 or later
 *
 * JoomlaPack Installer 4 automation
 */

defined('_JPI') or die('Direct access is not allowed');

class JPAutomation
{
	/**
	 * @var bool Is there automation information available?
	 */
	var $_hasAutomation = false;
	
	/**
	 * @var array The jpi4automation.ini contents, in array format
	 */
	var $_automation = array();
	
	/**
	 * Singleton implementation
	 * @return JPAutomation
	 */
	function &getInstance()
	{
		static $instance;

		if(empty($instance))
		{
			$instance = new JPAutomation();
		}

		return $instance;
	}
	
	/**
	 * Loads and parses the automation INI file
	 * @return JPAutomation
	 */
	function JPAutomation()
	{
		// Initialize
		$this->_hasAutomation = false;
		$this->_automation = array();

		// Try to load the jpi4automation.ini file
		$fn_rel = '..'.DS.'jpi4automation.ini';
		$fn_abs = JPATH_SITE.DS.'jpi4automation.ini';
		
		// Can I access the relative path?
		if(@file_exists($fn_rel))
		{
			$filename = $fn_rel; // Yes, use relative path
		} else {
			$filename = $fn_abs; // No, use absolute path
		}
		if(@file_exists($filename))
		{
			$this->_automation = _parse_ini_file($filename, true);
			if(!isset($this->_automation['jpi4']))
			{
				$this->_automation = array();
			}
			else
			{
				$this->_hasAutomation = true;	
			}
		}
	}
	
	/**
	 * Do we have automation?
	 * @return bool True if jpi4automation.ini exists and has a jpi4 section
	 */
	function hasAutomation()
	{
		return $this->_hasAutomation;
	}
	
	/**
	 * Returns an automation section. If the section doesn't exist, it returns an empty array.
	 * @param string $section [optional] The name of the section to load, defaults to 'jpi4'
	 * @return array 
	 */
	function getSection($section = 'jpi4')
	{
		if(!$this->_hasAutomation)
		{
			return array();
		}
		else
		{
			if(isset($this->_automation[$section]))
			{
				return $this->_automation[$section];	
			} else {
				return array();
			}
		}
	}
	
}